Eagle-1 Cockpit Pack 0.9

PRIVATE LOCAL COMBINATION; mission behavior still needs testing.
Contains Eagle1 Maelstrom v5, Vehicle Flight Control 1.0.1, Advanced Tank Hull/Turret and our cockpit/icon/payload changes. Original authors retain ownership of their components; obtain their permission before redistributing this combined archive.

Install this ONE Eagle entry with Bingus Shared Loader v18 and HD2Runtime 0.40.0 (https://github.com/SkyeShade/HD2Runtime). Disable the six original Eagle component entries and Tank Seat Kit. Keep originals installed for rollback. Other mods remain independent.

I: flight. X or 1-7: select one of seven Eagle weapons (500kg x2, airstrike x3, cluster x4, napalm x3, rockets x8, gas x2, smoke x4). B: fire the selected weapon. Home: rearm run while landed and stopped; a service Pelican flies in and hovers over the parked Eagle for the 60-second run that refills every weapon. Insert is unused now.
Normal camera on foot; cockpit mode and HUD are requested only in the verified Maelstrom pilot/gunner seat, landed or flying. The first-person eye now sits inside the canopy (0.6 m forward, 1.15 m up); the fake blue canopy frame is removed, leaving only the crosshair and the ammo panel. A parked seat found by proximity no longer needs a flight toggle. Fired weapons launch along the nose - toward the crosshair - not straight down. Turn/roll feel tuned through the VFC options file (turn 100%, roll 85%) and the ship now sinks under gravity when you let go instead of freezing in midair (hover_hold off in the VFC patch).
Only the 500kg projectile is proven in game; the other six are unverified donors. Super Destroyer docking is not implemented.
